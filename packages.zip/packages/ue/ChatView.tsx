import React from 'react';
import { generateChatResponseNew, generateChatResponse } from '../../src/services/geminiService';

interface Message {
  role: 'user' | 'agent';
  content: string;
}

interface ChatViewProps {
  userName?: string;
  systemInstruction?: string;
}

export const ChatView: React.FC<ChatViewProps> = ({
  userName = 'Elisa',
  systemInstruction = 'You are a helpful HR assistant.'
}) => {
  const [messages, setMessages] = React.useState<Message[]>([]);
  const [input, setInput] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);

    // Save to recent chats in local storage
    if (typeof window !== 'undefined') {
      const recentChats = JSON.parse(localStorage.getItem('recent_chats') || '[]');
      recentChats.unshift({
        id: Date.now().toString(),
        prompt: input,
        date: new Date().toLocaleString('en-US', { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: 'numeric', hour12: true })
      });
      localStorage.setItem('recent_chats', JSON.stringify(recentChats.slice(0, 20)));
    }

    setInput('');
    setIsLoading(true);

    try {
      let response = '';
      try {
        response = await generateChatResponseNew(input, systemInstruction);
      } catch (err) {
        console.warn("generateChatResponseNew failed, trying fallback:", err);
        const fallbackPrompt = `${systemInstruction}\n\n${input}`;
        response = await generateChatResponse(fallbackPrompt);
      }
      const agentMessage: Message = { role: 'agent', content: response };
      setMessages(prev => [...prev, agentMessage]);
    } catch (error) {
      console.error("Failed to get response:", error);
      const errorMessage: Message = { role: 'agent', content: "Sorry, I encountered an error. Please try again." };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full min-h-[calc(100vh-112px)] flex flex-col font-google-sans relative" id="chat-view">

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 min-h-0 overflow-y-auto">
        {messages.length === 0 ? (
          /* Welcome Section from JSON */
          <div className="text-center space-y-2 flex flex-col items-center" id="welcome-text">
            <h1 className="text-2xl font-medium bg-gradient-to-r from-[#078EFB] to-[#AC87EB] bg-clip-text text-transparent">
              Hello, {userName}
            </h1>
            <p className="text-3xl font-normal text-[#1F1F1F]">
              How can I help today?
            </p>
          </div>
        ) : (
          /* Chat History (Simple for now) */
          <div className="w-full max-w-3xl space-y-6" id="chat-history">
            {messages.map((msg, index) => (
              <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[70%] p-4 rounded-2xl ${msg.role === 'user' ? 'bg-[#E9EEF6] text-[#1F1F1F]' : 'bg-[#F0F4F9] text-[#1F1F1F]'
                  }`}>
                  {msg.content}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-[#F0F4F9] p-4 rounded-2xl text-[#444746]">
                  Typing...
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Input Area at Bottom */}
      <div className="w-full flex flex-col items-center bg-[#F8FAFD] pt-4 pb-6 px-4 sticky bottom-0 z-10" id="input-area">
        {/* Chips Cluster above input */}
        {messages.length === 0 && (
          <div className="flex flex-wrap gap-2 mb-4 justify-center" id="intent-chips">
            <button className="bg-[#EBF2FE] text-[#0842A0] rounded-full px-4 py-2 text-sm font-medium hover:bg-[#D3E3FD] transition-colors">
              Get support from People Ops
            </button>
            <button className="bg-[#E9EEF6] text-[#1F1F1F] rounded-full px-4 py-2 text-sm font-medium hover:bg-[#DFE4EC] transition-colors">
              What can you do?
            </button>
            <button className="bg-[#E9EEF6] text-[#1F1F1F] rounded-full px-4 py-2 text-sm font-medium hover:bg-[#DFE4EC] transition-colors">
              Book vacation
            </button>
            <button className="bg-[#E9EEF6] text-[#1F1F1F] rounded-full px-4 py-2 text-sm font-medium hover:bg-[#DFE4EC] transition-colors">
              Grow in my role
            </button>
          </div>
        )}

        {/* Input Field from JSON */}
        <div className="relative w-full max-w-3xl" id="prompt-input">
          <div className="flex items-center w-full min-h-[56px] bg-white rounded-[28px] border border-[#747775] px-6 py-2">
            <textarea
              className="flex-1 bg-transparent border-none focus:outline-none text-base text-[#444746] placeholder-[#444746] resize-none h-6"
              placeholder="Ask a question"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
            />
            <button
              className={`w-10 h-10 flex items-center justify-center rounded-full ml-2 transition-colors ${input.trim() ? 'bg-[#0B57D0] text-white' : 'text-[#444746] opacity-50 cursor-not-allowed'
                }`}
              onClick={handleSend}
              disabled={!input.trim()}
            >
              <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-5 h-5">
                <path d="M3 20V4L22 12L3 20ZM5 17L16.85 12L5 7V10.5L11 12L5 13.5V17ZM5 17V12V7V10.5V13.5V17Z" fill="currentColor" />
              </svg>
            </button>
          </div>

          {/* Disclaimer */}
          <p className="text-xs text-[#444746] text-center mt-3">
            AI sometimes generates inaccurate info, so double-check responses.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ChatView;
